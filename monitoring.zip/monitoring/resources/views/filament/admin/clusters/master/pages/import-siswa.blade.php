<x-filament::page>
    <div class="text-center">
        <h1 class="text-xl font-bold">Halaman Import Siswa</h1>
        <p class="text-gray-500">Gunakan tombol di atas untuk mengimpor data siswa.</p>
    </div>
</x-filament::page>