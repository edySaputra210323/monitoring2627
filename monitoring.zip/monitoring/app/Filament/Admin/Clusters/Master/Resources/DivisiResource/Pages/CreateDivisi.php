<?php

namespace App\Filament\Admin\Clusters\Master\Resources\DivisiResource\Pages;

use App\Filament\Admin\Clusters\Master\Resources\DivisiResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateDivisi extends CreateRecord
{
    protected static string $resource = DivisiResource::class;
}
