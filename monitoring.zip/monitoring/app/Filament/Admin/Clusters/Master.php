<?php

namespace App\Filament\Admin\Clusters;

use Filament\Clusters\Cluster;

class Master extends Cluster
{
    protected static ?string $navigationIcon = 'heroicon-o-squares-2x2';
}
